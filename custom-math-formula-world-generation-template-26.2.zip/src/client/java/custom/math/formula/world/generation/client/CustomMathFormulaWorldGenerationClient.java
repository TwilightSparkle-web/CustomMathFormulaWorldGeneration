package custom.math.formula.world.generation.client;

import net.fabricmc.api.ClientModInitializer;

public class CustomMathFormulaWorldGenerationClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}